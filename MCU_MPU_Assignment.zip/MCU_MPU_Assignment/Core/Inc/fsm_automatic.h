/*
 * fsm_automatic.h
 *
 *  Created on: Dec 7, 2023
 *      Author: ASUS
 */

#ifndef INC_FSM_AUTOMATIC_H_
#define INC_FSM_AUTOMATIC_H_

extern int T_RED;
extern int T_AMBER;
extern int T_GREEN;

void fsm_automatic();
void led_config();

#endif /* INC_FSM_AUTOMATIC_H_ */
