/*
 * input_processing.h
 *
 *  Created on: Dec 7, 2023
 *      Author: ASUS
 */

#ifndef INC_INPUT_PROCESSING_H_
#define INC_INPUT_PROCESSING_H_

void fsm_button_processing();

#endif /* INC_INPUT_PROCESSING_H_ */
