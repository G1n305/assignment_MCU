/*
 * fsm_manual.h
 *
 *  Created on: Dec 7, 2023
 *      Author: ASUS
 */

#ifndef INC_FSM_MANUAL_H_
#define INC_FSM_MANUAL_H_

void fsm_red_manual();
void fsm_amber_manual();
void fsm_green_manual();

#endif /* INC_FSM_MANUAL_H_ */
